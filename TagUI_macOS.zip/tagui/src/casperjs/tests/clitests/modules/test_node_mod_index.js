var casper = require('casper').create();
var bar = require('bar');
console.log(bar);
casper.exit();
